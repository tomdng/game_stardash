# DO NOT MODIFY THESE IMPORTS
from games.catastrophe.ai import AI
from games.catastrophe.game import Game
from games.catastrophe.game_object import GameObject
from games.catastrophe.job import Job
from games.catastrophe.player import Player
from games.catastrophe.structure import Structure
from games.catastrophe.tile import Tile
from games.catastrophe.unit import Unit

# <<-- Creer-Merge: init -->> - Code you add between this comment and the end comment will be preserved between Creer re-runs.
# if you need to initialize this module with custom logic do so here
# <<-- /Creer-Merge: init -->>
