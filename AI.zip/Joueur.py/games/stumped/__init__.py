# DO NOT MODIFY THESE IMPORTS
from games.stumped.ai import AI
from games.stumped.game import Game
from games.stumped.beaver import Beaver
from games.stumped.game_object import GameObject
from games.stumped.job import Job
from games.stumped.player import Player
from games.stumped.spawner import Spawner
from games.stumped.tile import Tile

# <<-- Creer-Merge: init -->> - Code you add between this comment and the end comment will be preserved between Creer re-runs.
# if you need to initialize this module with custom logic do so here
# <<-- /Creer-Merge: init -->>
