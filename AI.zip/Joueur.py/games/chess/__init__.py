# DO NOT MODIFY THESE IMPORTS
from games.chess.ai import AI
from games.chess.game import Game
from games.chess.game_object import GameObject
from games.chess.player import Player

# <<-- Creer-Merge: init -->> - Code you add between this comment and the end comment will be preserved between Creer re-runs.
# if you need to initialize this module with custom logic do so here
# <<-- /Creer-Merge: init -->>
