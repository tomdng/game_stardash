# DO NOT MODIFY THESE IMPORTS
from games.checkers.ai import AI
from games.checkers.game import Game
from games.checkers.checker import Checker
from games.checkers.game_object import GameObject
from games.checkers.player import Player

# <<-- Creer-Merge: init -->> - Code you add between this comment and the end comment will be preserved between Creer re-runs.
# if you need to initialize this module with custom logic do so here
# <<-- /Creer-Merge: init -->>
